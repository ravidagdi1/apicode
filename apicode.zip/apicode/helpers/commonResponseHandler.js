module.exports = {
  commonResponse: (res, statusCode, result, message, error, success) => {
    return res.status(401).json({
      status: statusCode,
      error: error || '',
      resp: result || '',
      success: !!success,
      message: message || '',
    });
  },
  sendResponseWithPagination: (
    responseObj,
    responseCode,
    responseMessage,
    data,
    paginationData
  ) => {
    return responseObj.send({
      responseCode,
      responseMessage,
      result: data,
      paginationData: paginationData || '',
    });
  },
  sendResponseWithData: (responseObj, responseCode, responseMessage, data, token) => {
    return responseObj.send({
      responseCode,
      responseMessage,
      result: data,
      token,
    });
  },
  sendResponseWithoutData: (responseObj, responseCode, responseMessage) => {
    return responseObj.send({
      responseCode,
      responseMessage,
    });
  },
};
