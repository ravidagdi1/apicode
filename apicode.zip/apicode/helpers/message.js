/**
 * @description All the Error messages that needed to be sent to Admin or App
 * @type {Object}
 */
module.exports.ErrorMessage = Object.freeze({
  INVALID_TOKEN: 'Unauthorized user.',
  INTERNAL_ERROR: 'Internal Server Error.',
  INVALID_CREDENTIAL: 'Invalid credentials.',
  SOMETHING_WRONG: 'Something went wrong.',
  NO_TOKEN: 'Please provide token.',
  INCORRECT_JWT: 'Invalid JWT token.',
  FORBIDDEN: 'There was an error in sending email.',
  sessionExpire: 'Session is expired , please logged in again.',
  PASSWORD_WRONG:"Invalid password.",
  NOT_FOUND:"Data not found.",
  USER_NOT_FOUND:"User not found.",
  BAD_REQUEST:"Bad request.",
  ID_MISSING:"Please provide id.",
  INVALID_PARAMETER:"Invalid parameter.",
  FAIL_UPLOAD:"Uploading failed.",
  ALREADY_AVAILABLE :'Cms Page already inserted.',
  EMAIL_ALREADY_AVAILABLE :'Email already in use.'
});

/**
 * @description All the Success messages that needed to be sent to App or Admin
 * @type {Object}
 */
module.exports.SuccessMessage = Object.freeze({
  LOGIN_SUCCESS: 'logged in successfully.',
  MOBILE_ALREADY_AVAILABLE :'Mobile number already registered.',
  GAME_UPLOADED:'Game successfully uploaded.',
  CURATION_UPLOADED: 'Curation successfully uploaded.',
  DATA_FOUND:'Data found successfully.',
  FORGET_SUCCESS: 'A password code has been sent to your registered ID.',
  RESET_SUCCESS: 'Your password was successfully changed.',
  // AUTHORIZATION: 'This User is Authorized.',
  ACCOUNT_CREATION: 'Your account has been created successfully.',
  // DETAIL_GET: 'Details have been fetched successfully.',
  // DATA_FOUND: 'Requested data found.',
  PROFILE_DETAILS: 'Your profile detail was updated sucessfully.',
  STATUS_UPDATED: 'Your Status has been changed successfully.',
  UPDATE_SUCCESS: 'Successfully updated.',
  INSERT_SUCCESS: 'Successfully inserted.',
  IMAGE_UPLOAD:"Images uploaded.",
  // BLOCK_SUCCESS: 'Successfully blocked.',
  // UNBLOCK_SUCCESS: 'Successfully activated.',
  DELETE_SUCCESS: 'Successfully deleted.'
});
