//* ************************************************** self init config********************************
module.exports = {
  configuration: () => {
    const finalConfig = {};
    return new Promise(async (resolve, reject) => {
      try {
        finalConfig.node_port = 5000;
        finalConfig.JWT_secureToken= "gamers@123456789";
        finalConfig.cloudinary_CLOUD_NAME = "";
        finalConfig.cloudinary_API_KEY = "";
        finalConfig.cloudinary_API_SECRET = "";
        finalConfig.cloudFrontDomainAsset="",
        finalConfig.bucketName="ghosts3images",
        finalConfig.accessKeyId= "AKIAYPVEHOTDRU5KPUNF",
        finalConfig.secretAccessKey= "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",
        finalConfig.s3_region= "ap-south-1",
        finalConfig.authEmail= "support@phpsupport.in",
        finalConfig.authPass= "9oYs(;5,sFbq",
        finalConfig.fromEmail= "playmaker@gmail.com",
        finalConfig.mailHost= "mail.phpsupport.in",
        finalConfig.mailPort= 587
        resolve(finalConfig);
      } catch (error) {
        console.log("error in configuration file " + error);
      }
    })
    //extra
  }
  //* ********************************* */
};