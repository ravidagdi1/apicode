const cloudinary = require('cloudinary').v2;
cloudinary.config({
    cloud_name: global.gConfig.cloudinary_CLOUD_NAME,
    api_key: global.gConfig.cloudinary_API_KEY,
    api_secret: global.gConfig.cloudinary_API_SECRET
});
const Q = require('q');
const MaskData = require('maskdata');

module.exports = {
  /**
    * Function Name :Generate maskPhoneNumber
    * Description :Generate maskPhoneNumber
    * @return  response
    */
   maskConvertFunction: (mobileNumber, unmaskedStartDigits = 5, unmaskedEndDigits = 2) => {
    const maskPhoneOptions = {
        // Character to mask the data
        // default value is '*'
        maskWith: "*",

        //Should be positive Integer
        // If the starting 'n' digits needs to be unmasked
        // Default value is 4
        unmaskedStartDigits: unmaskedStartDigits,

        // Should be positive Integer
        //If the ending 'n' digits needs to be unmasked
        // Default value is 1
        unmaskedEndDigits: unmaskedEndDigits
    };
    const phoneNumber = mobileNumber;
    const maskedPhoneNumber = MaskData.maskPhone(phoneNumber, maskPhoneOptions);
    console.log(maskedPhoneNumber)
    return maskedPhoneNumber;
},
}