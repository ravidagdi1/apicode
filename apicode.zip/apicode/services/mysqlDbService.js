// Get the mysql service
const mysql = require('mysql2');
// Add the credentials to access your database
const conn = mysql.createConnection({
    host     : 'localhost',
    user     : 'root',
    password : '',
    database : 'ajay'
});
/*const conn = mysql.createConnection({
    host     : 'playmaker-db-instance.crj5rzihcckr.us-east-1.rds.amazonaws.com',
    user     : 'master',
    password : 'playmakerpass2023',
    database : 'testdb',
    port     : '3306',
});*/
conn.connect(function(err) {
    if(err){
        console.log(err);
        console.log(err.code);
        console.log(err.fatal);
    } else {
        console.log('connected......');
    }
});
module.exports = {
    
    insertRecord: (query, table) => {
        return new Promise((resolve, reject) => {
            try {
                console.log("Adding a new item...");
                conn.query(query, async function (err, data) {
                    if (err) {
                        console.error(
                            "Unable to Insert item. Error JSON:",
                            JSON.stringify(err, null, 2)
                        );
                        reject(err);
                    } else {
                        console.log("InsertItem succeeded:", JSON.stringify(data, null, 2));
                        resolve(data);
                    }
                });
                //conn.end();
            } catch (error) {
                console.log("error in insertMysqlDb====>", error);
                return reject(error);
            }
        })
    },
    readQueryById: (id = '', table) => {
        return new Promise((resolve, reject) => {
            try {
                var params = "SELECT * FROM " + table + " WHERE id = '" + id +"'";
                console.log("query====>", params);
                conn.query(params, function (err, data) {
                    if (err) {
                        console.error("Unable to query. Error:", JSON.stringify(err, null, 2));
                    } else {
                        console.log("Query succeeded.", data);
                        resolve(data)
                    }
                });
                //conn.end();
            }
            catch (error) {
                console.log("error in checkRecordsInMySqlDb \n", error);
                return reject(error);
            }
        })
    },
    readQueryByOrderId: (orderId = '', table) => {
        return new Promise((resolve, reject) => {
            try {
                var params = "SELECT * FROM " + table + " WHERE orderId = '" + orderId +"'";
                console.log("query====>", params);
                conn.query(params, function (err, data) {
                    if (err) {
                        console.error("Unable to query. Error:", JSON.stringify(err, null, 2));
                    } else {
                        console.log("Query succeeded.", data);
                        resolve(data)
                    }
                });
                //conn.end();
            }
            catch (error) {
                console.log("error in checkRecordsInMySqlDb \n", error);
                return reject(error);
            }
        })
    },
    readQueryByEmailCode: (email = '', code = '', table) => {
        return new Promise((resolve, reject) => {
            try {
                var params = "SELECT * FROM " + table + " WHERE code = '" + code +"' and email = '" + email +"'";
                console.log("query====>", params);
                conn.query(params, function (err, data) {
                    if (err) {
                        console.error("Unable to query. Error:", JSON.stringify(err, null, 2));
                    } else {
                        console.log("Query succeeded.", data);
                        resolve(data)
                    }
                });
                //conn.end();
            }
            catch (error) {
                console.log("error in checkRecordsInMySqlDb \n", error);
                return reject(error);
            }
        })
    },
    readQueryByEmailWithLoginType: (email = '',loginType = '',table) => {
        return new Promise((resolve, reject) => {
            try {
                var params = "SELECT * FROM " + table + " WHERE loginType = '" + loginType +"' and email = '" + email +"'";
                console.log("query====>", params);
                conn.query(params, function (err, data) {
                    if (err) {
                        console.error("Unable to query. Error:", JSON.stringify(err, null, 2));
                    } else {
                        console.log("Query succeeded.", data);
                        resolve(data)
                    }
                });
                //conn.end();
            }
            catch (error) {
                console.log("error in checkRecordsInMySqlDb \n", error);
                return reject(error);
            }
        })
    },
    readQueryByEmail: (email = '', table) => {
        return new Promise((resolve, reject) => {
            try {
                var params = "SELECT * FROM " + table + " WHERE email = '" + email +"'";
                console.log("query====>", params);
                conn.query(params, function (err, data) {
                    if (err) {
                        console.error("Unable to query. Error:", JSON.stringify(err, null, 2));
                    } else {
                        console.log("Query succeeded.", data);
                        resolve(data)
                    }
                });
                //conn.end();
            }
            catch (error) {
                console.log("error in checkRecordsInMySqlDb \n", error);
                return reject(error);
            }
        })
    },
    readQuery: (query = '') => {
        return new Promise((resolve, reject) => {
            try {
                console.log("query====>", query);
                conn.query(query, function (err, data) {
                    if (err) {
                        console.error("Unable to query. Error:", JSON.stringify(err, null, 2));
                    } else {
                        //console.log("Query succeeded.", data);
                        resolve(data)
                    }
                });
                //conn.end();
            }
            catch (error) {
                console.log("error in checkRecordsInMySqlDb \n", error);
                return reject(error);
            }
        })
    },
    /**
     * @param id
     * Function Name : uodate item in mysqlDb table function.
     * Description :   uodate item in mysqlDb table function.
     * @return  response
     */
    updateTable: async (query) => {
        return new Promise((accept, reject) => {
            try {
                console.log("params update====>", query);
                //docClient.update(query, async function (err, data) {
                conn.query(query, async function (err, data) {
                    if (err) {
                        console.error(
                            "Unable to update item. Error JSON:",
                            JSON.stringify(err, null, 2)
                        );
                        reject(err);
                    }
                    else {
                        console.log("UpdateItem succeeded:", JSON.stringify(data, null, 2));
                        accept(data);
                    }
                });
                //conn.end();
            } catch (error) {
                console.log("error in updateMysqlTable \n", error);
                return reject(error);
            }
        });
    },
    /**
     * @param id
     * Function Name : deleteItemFromMysqlDb function.
     * Description :   deleteItemFromMysqlDb function.
     * @return  response
     */
    deleteItem: async (table, id) => {
        return new Promise((resolve, reject) => {
            try {
                let deletedItem = `DELETE FROM ${table} WHERE id=${id}`;
                conn.query(deletedItem, async function (err, data) {
                    console.log('FAIL:  Error del - deleteItemFromMysqlDb \n' + err);
                    if (err) {
                        console.error(
                            "Unable to update item. Error JSON:",
                            JSON.stringify(err, null, 2)
                        );
                        return reject(err);
                    }
                    else {
                        return resolve(data);
                    }
                })
                //conn.end();
            }
            catch (error) {
                console.log("error in delete records in mysqlDb ==>\n", error);
                return reject(error);
            }
        })
    },
    mulDeleteItem: async (table, id) => {
        return new Promise((resolve, reject) => {
            try {
                let deletedItem = `DELETE FROM ${table} WHERE id IN (${id})`;
                conn.query(deletedItem, async function (err, data) {
                    //console.log(' FAIL:  Error del - deleteItemFromMysqlDb \n' + err);
                    if (err) {
                        console.error(
                            "Unable to update item. Error JSON:",
                            JSON.stringify(err, null, 2)
                        );
                        return reject(err);
                    }
                    else {
                        return resolve(data);
                    }
                })
                //conn.end();
            }
            catch (error) {
                console.log("error in delete records in mysqlDb ==>\n", error);
                return reject(error);
            }
        })
    },
    deleteItemEx: async (table, id) => {
        return new Promise((resolve, reject) => {
            try {
                let deletedItem = `DELETE FROM ${table} WHERE subscriptionId=${id}`;
                conn.query(deletedItem, async function (err, data) {
                    //console.log('FAIL:  Error del - deleteItemFromMysqlDb \n' + err);
                    if (err) {
                        console.error(
                            "Unable to update item. Error JSON:",
                            JSON.stringify(err, null, 2)
                        );
                        return reject(err);
                    }
                    else {
                        return resolve(data);
                    }
                })
                //conn.end();
            }
            catch (error) {
                console.log("error in delete records in mysqlDb ==>\n", error);
                return reject(error);
            }
        })
    },
    deleteOrder: async (table, id) => {
        return new Promise((resolve, reject) => {
            try {
                let deletedItem = `DELETE FROM ${table} WHERE orderId=${id}`;
                conn.query(deletedItem, async function (err, data) {
                    //console.log('FAIL:  Error del - deleteItemFromMysqlDb \n' + err);
                    if (err) {
                        console.error(
                            "Unable to update item. Error JSON:",
                            JSON.stringify(err, null, 2)
                        );
                        return reject(err);
                    }
                    else {
                        return resolve(data);
                    }
                })
                //conn.end();
            }
            catch (error) {
                console.log("error in delete records in mysqlDb ==>\n", error);
                return reject(error);
            }
        })
    },
    /*// Close the connection*/
    /*conn.end(function(){
        // The connection has been closed
    });*/
}
