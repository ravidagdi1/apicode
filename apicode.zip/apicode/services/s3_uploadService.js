const fs = require('fs');
const AWS = require('aws-sdk');

const s3 = new AWS.S3({
    accessKeyId: global.gConfig.accessKeyId || process.env.AWS_ACCESS_KEY,
    secretAccessKey: global.gConfig.secretAccessKey || process.env.AWS_SECRET_ACCESS_KEY,
    region: global.gConfig.s3_region
});
module.exports = {
  /**
    * @param id
    * Function Name : uploadS3_bucket
    * Description :  uploadS3_bucket API
    * @return  response
    */

    uploadFile: (fileName,path,type) => {
        return new Promise((resolve, reject) => {
            try {
                // fs.readFile(fileName, (err, data) => {
                //     if (err) throw err;
                    const file = require('fs').createReadStream(path);
                    console.log("file type>> ", file.type);
                    const params = {
                        Bucket: global.gConfig.bucketName, // pass your bucket name
                        Key: fileName, // file will be saved as testBucket/contacts.csv
                        ContentType: type,
                        ACL: 'public-read',
                        Body: file
                    };
                    s3.upload(params, function (s3Err, data) {
                        if (s3Err) {
                            return reject(s3Err);
                        }
                        console.log(`File uploaded successfully at ${data.Location}`);
                        //return resolve( global.gConfig.cloudFrontDomainAsset+"/"+fileName);
                        return resolve( data.Location);
                        //return resolve( data.Location+"/"+fileName);
                    });
                // });

            } catch (error) {
                return reject(error);
            }
        })

    }

}