const axios = require('axios');

const get = (request) => {
      return axios(request)
        .then((response) => response.data)
        .catch((error) => {
        console.error(error);
        });
}

module.exports = {
    get
}