const multiparty = require('multiparty');

/**
 * Function Name :Check token validation
 * Description : Middleware auth to check valid jwt token
 * @return callback response
 */
function changeContentType(req, res, next) {
    console.log('start change ContentType');
    const form = new multiparty.Form();
    if (req.headers['content-type'] !== 'application/x-www-form-urlencoded') {
        form.parse(req, (error, fields, files) => {

            try {
                const profileData = fields.request?JSON.parse(fields.request[0]):{};
                if (!error) {
                    req.body.request = profileData;
                    req.body.files = files;
                    next();
                    console.log('End change ContentType');
                } else {
                    next(error);
                }
            } catch (e) {
                return res.status(400).send({
                    status: 400,
                    success: false,
                    error: 'Bad request.',
                    message: 'Invalid JSON provided.'
                });
            }
        });
    } else {
        req.body.request = JSON.parse(req.body.request);
        next();
        console.log('End change ContentType');
    }
}
module.exports.changeContentType = changeContentType;
