const jwt = require('jsonwebtoken');
const { commonResponse: response } = require('../helpers/commonResponseHandler');
const { ErrorMessage } = require('../helpers/message');
const { ErrorCode } = require('../helpers/statusCode');
const mysqlDbService = require('../services/mysqlDbService');
module.exports={
   /**
     * Function Name :Check token validation
     * Description : Middleware auth to check valid jwt token
     * @return callback response
  */
    verifyToken: (req, res, next) => {
      try {
        let token;
        token = req.headers.authorization || '';
        if (!token.includes('Bearer') || !token ) {
          return response(res, ErrorCode.UNAUTHORIZED, [], ErrorMessage.INVALID_TOKEN, 'UNAUTHORIZED.');
        }
        token = token.split('Bearer')[1];
        jwt.verify(token.trim(), global.gConfig.JWT_secureToken, async (err, result) => {
          if (err) {
            console.log("Token error::", err);
            return response(res, ErrorCode.UNAUTHORIZED, [], ErrorMessage.INVALID_TOKEN, 'UNAUTHORIZED.');
          } else if (Date.now() < result.expire) {
            if (!result.id) {
              return response(res, ErrorCode.UNAUTHORIZED, [], ErrorMessage.INVALID_TOKEN, 'UNAUTHORIZED.');
            }
            let userId = result.id;
            //changes here query on elastic search
            let validUser = await mysqlDbService.readQueryById(userId,'tb_users');
            if (validUser.length > 0) {
              //check status as ACTIVE or not.
              validUser = validUser.map(e=>{
                if(e.status=="1"){
                  return e;
                }
              }).filter(Boolean);
            }

            if (validUser.length > 0) {
              req.userDetails = validUser;
              next();
            } else {
              return response(res, ErrorCode.UNAUTHORIZED, [], ErrorMessage.INVALID_TOKEN, 'UNAUTHORIZED.');
            }
          } else {
            return response(res, ErrorCode.sessionExpire, [], ErrorMessage.sessionExpire, 'UNAUTHORIZED.');
          }
        });
      } catch (error) {
        console.log("error in verify token authentication ",error)
        return response(res, ErrorCode.UNAUTHORIZED, [], ErrorMessage.INVALID_TOKEN, 'UNAUTHORIZED.',error);
      }
      },
       
}