const router = require('express').Router();
const userController = require('../controllers/v1/userController');
const cmspagesController = require('../controllers/v1/cmspagesController');
const contactController = require('../controllers/v1/contactController');
const contestController = require('../controllers/v1/contestController');
const { changeContentType } = require('../middlewares/middleware.contentType');
const auth=require('../middlewares/auth_handler');
 /**
 * @swagger
 * /api/v1/appLogin:
 *   post:
 *     tags:
 *       - PLAYG USER AUTH API
 *     description: Creating Docs for app user login 
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: email
 *         description: email is required.
 *         in: formData
 *         required: true
 *       - name: password
 *         description: password is required.
 *         in: formData
 *         required: true
 *     responses:
 *       200: 
 *         description: Data found successfully.
 *       500:
 *         description: Internal server error.
 *       501:
 *         description: Something went wrong.
 */
  router.post('/appLogin',userController.appLogin);
 /**
 * @swagger
 * /api/v1/signupUser:
 *   post:
 *     tags:
 *       - PLAYG USER AUTH API
 *     description: Creating Docs for signupUser 
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: firstName
 *         description: firstName is required.
 *         in: formData
 *         required: true
 *       - name: lastName
 *         description: lastName is required.
 *         in: formData
 *         required: true
 *       - name: email
 *         description: email is required.
 *         in: formData
 *         required: true
 *       - name: mobileNumber
 *         description: mobileNumber is required.
 *         in: formData
 *         required: true
 *       - name: country
 *         description: country is required.
 *         in: formData
 *         required: true
 *       - name: other
 *         description: other is optional.
 *         in: formData
 *         required: false
 *       - name: state
 *         description: state is optional.
 *         in: formData
 *         required: false
 *       - name: password
 *         description: password is required.
 *         in: formData
 *         required: true
 *       - name: ipAddress
 *         description: ipAddress is required.
 *         in: formData
 *         required: true
 *     responses:
 *       200: 
 *         description: Data found successfully.
 *       500:
 *         description: Internal server error.
 *       501:
 *         description: Something went wrong.
 */
 router.post('/signupUser',userController.signupUser);
 /**
 * @swagger
 * /api/v1/updateUserDetail:
 *   post:
 *     tags:
 *       -  PLAYG USER AUTH API
 *     description: fetch update user detail
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: Authorization
 *         description: Authorization key is missing in headers.
 *         in: header
 *         required: true
 *       - name: firstName
 *         description: firstName is required.
 *         in: formData
 *         required: true
 *       - name: lastName
 *         description: lastName is required.
 *         in: formData
 *         required: true
 *       - name: email
 *         description: email is required.
 *         in: formData
 *         required: true
 *       - name: mobileNumber
 *         description: mobileNumber is required.
 *         in: formData
 *         required: true
 *       - name: country
 *         description: country is optional.
 *         in: formData
 *         required: false
 *       - name: other
 *         description: other is optional.
 *         in: formData
 *         required: false
 *       - name: state
 *         description: state is optional.
 *         in: formData
 *         required: false
 *     responses:
 *       200:
 *         description: Data found successfully. ,
 *       501:
 *         description: Internal server error.
 */
router.post('/updateUserDetail', auth.verifyToken, userController.updateUserDetail);
 /** 
 * @swagger
 * /api/v1/resetPassword:
 *   post:
 *     tags:
 *       - PLAYG USER AUTH API
 *     description: Creating Docs for resetPassword 
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: Authorization
 *         description: Authorization key is missing in headers.
 *         in: header
 *         required: true
 *       - name: email
 *         description: email is required.
 *         in: formData
 *         required: true
 *       - name: password
 *         description: password is required.
 *         in: formData
 *         required: true
 *       - name: oldPassword
 *         description: old password is required.
 *         in: formData
 *         required: true
 *     responses:
 *       200: 
 *         description: Data found successfully.
 *       500:
 *         description: Internal server error.
 *       501:
 *         description: Something went wrong.
 */
 router.post('/resetPassword', auth.verifyToken, userController.resetPassword);
 /** 
 * @swagger
 * /api/v1/resetPasswordAfterForgot:
 *   post:
 *     tags:
 *       - PLAYG USER AUTH API
 *     description: Creating Docs for resetPassword 
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: email
 *         description: email is required.
 *         in: formData
 *         required: true
 *       - name: password
 *         description: password is required.
 *         in: formData
 *         required: true
 *       - name: code
 *         description: code is required.
 *         in: formData
 *         required: true
 *     responses:
 *       200: 
 *         description: Data found successfully.
 *       500:
 *         description: Internal server error.
 *       501:
 *         description: Something went wrong.
 */
 router.post('/resetPasswordAfterForgot', userController.resetPasswordAfterForgot);
 /**
  * @swagger
  * /api/v1/forgetPassword:
  *   post:
  *     tags: 
  *       - PLAYG USER AUTH API
  *     description: Creating Docs for forgetPassword 
  *     produces:
  *       - application/json
  *     parameters:
  *       - name: Authorization
  *         description: Authorization key is missing in headers.
  *         in: header
  *         required: false
  *       - name: email
  *         description: email is required.
  *         in: formData
  *         required: true
  *     responses:
  *       200: 
  *         description: Data found successfully.
  *       500:
  *         description: Internal server error.
  *       501:
  *         description: Something went wrong.
  */
  router.post('/forgetPassword', userController.forgetPassword);
 /**
  * @swagger
  * /api/v1/viewUserDetail:
  *   get:
  *     tags:
  *       -  PLAYG USER AUTH API
  *     description: fetch user detail
  *     produces:
  *       - application/json
  *     parameters:
  *       - name: Authorization
  *         description: Authorization key is missing in headers.
  *         in: header
  *         required: true
  *     responses:
  *       200:
  *         description: Data found successfully. ,
  *       501:
  *         description: Internal server error.
  */
router.get('/viewUserDetail', auth.verifyToken, userController.viewUserDetail);
/**
  * @swagger
  * /api/v1/contestLists:
  *   get:
  *     tags:
  *       -  PLAYG CONTEST API
  *     description: fetch list
  *     produces:
  *       - application/json
  *     parameters:
  *       - name: Authorization
  *         description: Authorization key is missing in headers.
  *         in: header
  *         required: false
  *     responses:
  *       200:
  *         description: Data found successfully. ,
  *       501:
  *         description: Internal server error.
  */
router.get('/contestLists', contestController.contestLists);
/**
 * @swagger
 * /api/v1/contestDetail:
 *   get:
 *     tags:
 *       -  PLAYG CONTEST API
 *     description: fetch contest detail
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: Authorization
 *         description: Authorization key is missing in headers.
 *         in: header
 *         required: false
 *       - name: id
 *         in: query
 *         required: true
 *         description: id key is required.
 *       - name: userId
 *         in: query
 *         required: false
 *         description: userId key is optional.
 *     responses:
 *       200:
 *         description: Data found successfully. ,
 *       501:
 *         description: Internal server error.
 */
router.get('/contestDetail', contestController.contestDetail);
/**
   * @swagger
   * /api/v1/uploadContest:
   *   put:
   *     tags:
   *       - PLAYG CONTEST API
   *     description: API for adding contest
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: Authorization
   *         description: Authorization key is missing in headers.
   *         in: header
   *         required: true
   *       - name: json
   *         in: body
   *         required: true
   *         description: json is required in body.
   *         example: {
   *                 "contest_id":"0",
                     "items":[
                       {
                         "question_id":"question id",
                         "question":"question",
                         "type":"0",
                         "userAnswer":"user answer"
                       }
                     ]
             }
   *     responses:
   *       200:
   *         description: Contest uploaded successfully. ,
   *       501:
   *         description: Internal server error.
   */
  router.put('/uploadContest', auth.verifyToken,contestController.uploadContest);
  /**
 * @swagger
 * /api/v1/contestReport:
 *   get:
 *     tags:
 *       -  PLAYG CONTEST API
 *     description: fetch contest report
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: Authorization
 *         description: Authorization key is missing in headers.
 *         in: header
 *         required: false
 *       - name: id
 *         in: query
 *         required: true
 *         description: id key is required.
 *     responses:
 *       200:
 *         description: Data found successfully. ,
 *       501:
 *         description: Internal server error.
 */
router.get('/contestReport', contestController.contestReport);
/**
 * @swagger
 * /api/v1/userReport:
 *   get:
 *     tags:
 *       -  PLAYG CONTEST API
 *     description: fetch user report
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: Authorization
 *         description: Authorization key is missing in headers.
 *         in: header
 *         required: true
 *     responses:
 *       200:
 *         description: Data found successfully. ,
 *       501:
 *         description: Internal server error.
 */
router.get('/userReport', auth.verifyToken, contestController.userReport);
/**
 * @swagger
 * /api/v1/claimPrize:
 *   post:
 *     tags:
 *       - PLAYG CONTEST API
 *     description: Creating Docs for claim prize 
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: contest_id
 *         description: contest_id is required.
 *         in: formData
 *         required: true
 *       - name: price
 *         description: prize is required.
 *         in: formData
 *         required: true
 *       - name: rank
 *         description: rank is required.
 *         in: formData
 *         required: true
 *     responses:
 *       200: 
 *         description: Data found successfully.
 *       500:
 *         description: Internal server error.
 *       501:
 *         description: Something went wrong.
 */
router.post('/claimPrize',auth.verifyToken, contestController.claimPrize);
 /**
 * @swagger
 * /api/v1/cmspageLists:
 *   get:
 *     tags:
 *       -  PLAYG PAGES API
 *     description: fetch cmspages lists
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: Authorization
 *         description: Authorization key is missing in headers.
 *         in: header
 *         required: false
 *       - name: filter
 *         in: query
 *         required: false
 *         description: filter key is optional.
 *       - name: status
 *         description: status is optional (eg:-ACTIVE/DEACTIVE).
 *         type: string
 *         enum: [ACTIVE,DEACTIVE]
 *         in: query
 *         required: false
 *       - name: offset
 *         in: query
 *         required: true
 *         description: offset key is required.
 *       - name: limit
 *         in: query
 *         required: true
 *         description: limit key is required.
 *     responses:
 *       200:
 *         description: Data found successfully. ,
 *       501:
 *         description: Internal server error.
 */
 router.get('/cmspageLists', cmspagesController.cmspageLists);
 /**
  * @swagger
  * /api/v1/viewCmspageDetail:
  *   get:
  *     tags:
  *       -  PLAYG PAGES API
  *     description: fetch cmspage detail
  *     produces:
  *       - application/json
  *     parameters:
  *       - name: Authorization
  *         description: Authorization key is missing in headers.
  *         in: header
  *         required: false
  *       - name: id
  *         in: query
  *         required: true
  *         description: id key is required.
  *     responses:
  *       200:
  *         description: Data found successfully. ,
  *       501:
  *         description: Internal server error.
  */
router.get('/viewCmspageDetail', cmspagesController.viewCmspageDetail);
/**
   * @swagger
   * /api/v1/insertContact:
   *   post:
   *     tags:
   *       - PLAYG Contact API
   *     description: Creating Docs for add contact 
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: name
   *         description: name is required.
   *         in: formData
   *         required: true
   *       - name: email
   *         description: email is required.
   *         in: formData
   *         required: true
   *       - name: phone
   *         description: phone is required.
   *         in: formData
   *         required: true
   *       - name: message
   *         description: message is key optional.
   *         in: formData
   *         required: false
   *     responses:
   *       200: 
   *         description: Data found successfully.
   *       500:
   *         description: Internal server error.
   *       501:
   *         description: Something went wrong.
   */
 router.post('/insertContact',contactController.insertContact);
  
module.exports=router;