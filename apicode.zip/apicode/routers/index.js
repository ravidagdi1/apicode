
const userRouter = require('./userRouter');

module.exports = function (app) {

  app.use('/api/v1', userRouter);
  };
  