const express = require('express');
const app = express();
const cors = require('cors');
const morgan = require('morgan');
const config = require('./config/config');
const swaggerUi = require('swagger-ui-express');
const swaggerJSDoc = require('swagger-jsdoc');
const { v4: uuid } = require('uuid');
// console.log(uuid());
// console.log(uuid())
//* **************cache handelling***************/
/*var whitelist = ['http://mcq.namocart.in', 'http://gennextlogics.in'];
var corsOptions = {
  origin: function(origin, callback){
    var originIsWhitelisted = whitelist.indexOf(origin) !== -1;
    console.log("originIsWhitelisted-- " + originIsWhitelisted);
    callback(null, originIsWhitelisted);
  }
};*/
app.use(cors());
app.use(morgan('dev'));
app.use(express.json({ limit: '100mb' }));
app.use(express.urlencoded({ extended: true, limit: '100mb' }));

//********************Error Exception handelling ***********/
app.use((error, req, res, next) => {
  if (error instanceof SyntaxError) {
    // sendError(res, myCustomErrorMessage);
    return res.status(400).send({ status: 400, success: false, message: 'Bad request.' });
  }
  next();
});

app.get('/test',async(req,res)=>
{
  console.log("rest API");
  try {

    let data = '1';
    return res.send(data);
  } catch (error) {
    console.log("error in catch \n", error)
    return res.send(error);
  }
}
) 
process
  .on('unhandledRejection', (reason, p) => {
    console.log(`Unhandled Rejection at: Promise', ${p}, reason: ${reason}`);
    process.exit(1);
    // application specific logging, throwing an error, or other logic here
  })
  .on('uncaughtException', (err) => {
    console.log(`${new Date().toUTCString()} uncaughtException:${err.message}`);
    console.log(`${err.stack}`);
    process.exit(1);
  });



app.listen(5001, async () => {
  try {
    global.gConfig = await config.configuration();
    const routes = require('./routers');
    // console.log("globalData===>",global.gConfig)
    routes(app);
    app.use((err, req, res, next) => {console.log("err====>",err)})
    console.log('Server is running on ' + 5001)
  } catch (e) {
    console.log(`Server is not responding.${e}`);
  }
});
//* *****************************************swgger setup********************************* */
const swaggerDefinition = {
  info: {
    title: 'MVP_APP',
    version: '1.0.0',
    description: 'Swagger API Docs'
  },
  // host:`${global.gConfig.swaggerURL}`, // Host (optional)
  //  host:`localhost:7000`, // Host (optional)
  basePath: '/' // Base path (optional)
};

const options = {
  swaggerDefinition,
  apis: ['./routers/*.js'] // <-- not in the definition, but in the options
};

const swaggerSpec = swaggerJSDoc(options);

app.get('/swagger.json', (req, res) => {
  res.setHeader('Content-Type', 'application/json');
  res.send(swaggerSpec);
});
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerSpec));

//* ************************************************************************************ */
// module.exports = app;