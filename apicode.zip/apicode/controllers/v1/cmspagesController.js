const mysqlDbService = require('../../services/mysqlDbService');
const { ErrorMessage, SuccessMessage } = require('../../helpers/message');
module.exports = {
    cmspageLists: async (req, res) => {
        try {
            let { filter, status } = req.query;
            let query = `select * from tb_qhse`; 
            if (filter) {
                query += ` WHERE title LIKE '%${filter}%'`
            } else {
                if(status) {
                    query += ` WHERE status='${status}'`
                } 
            }
            let Search_cmspageLists = await mysqlDbService.readQuery(query);
            return res.status(200).send({
                success: (Search_cmspageLists.length > 0) ? true : false,
                status: 200,
                message: SuccessMessage.DATA_FOUND,
                resp: Search_cmspageLists
            })
        } catch (error) {
            console.log("error in Cmspage Lists  API===>\n", error);
            return res.status(501).send({
                success: false,
                status: 501,
                error: error,
                message: ErrorMessage.SOMETHING_WRONG
            })
        }
    },
    viewCmspageDetail: async (req, res) => {
        try {
            let { id } = req.query;
            let query = `select * from tb_qhse WHERE id='${id}'`; 
            let Search_viewCmspageDetail = await mysqlDbService.readQuery(query);
            return res.status(200).send({
                success: (Search_viewCmspageDetail.length > 0) ? true : false,
                status: 200,
                message: SuccessMessage.DATA_FOUND,
                resp: Search_viewCmspageDetail,
            })
        } catch (error) {
            console.log("error in page detail API===>\n", error);
            return res.status(501).send({
                success: false,
                status: 501,
                error: error,
                message: ErrorMessage.SOMETHING_WRONG
            })
        }
    }
}