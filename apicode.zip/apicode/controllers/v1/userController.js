const mysqlDbService = require('../../services/mysqlDbService');
const jwt = require('jsonwebtoken');
const mailer = require('nodemailer');
const { v4: uuidv4 } = require('uuid');
const bcrypt = require('bcryptjs');
const salt = bcrypt.genSaltSync(10);
const { ErrorMessage, SuccessMessage } = require('../../helpers/message');
const s3Services = require('../../services/s3_uploadService');
const transporter = mailer.createTransport({
    host: global.gConfig.mailHost,
    port: global.gConfig.mailPort,
    secure: false,
    auth: {
        user: global.gConfig.authEmail,
        pass: global.gConfig.authPass
    },
    tls: {
        rejectUnauthorized: false
    }
}); 
module.exports = {
    appLogin: async (req, res) => {
        try { 
            let { email, password } = req.body;
            console.log(email)
            if (!email) {
                return res.status(400).send({
                    status: 400,
                    success: false,
                    message: "email not available."
                });
            };
            if (!password) {
                return res.status(400).send({
                    status: 400,
                    success: false,
                    message: "password not available."
                });
            };
            let userData = await mysqlDbService.readQueryByEmail(email,'tb_users');
            console.log(userData)
            console.log("userData====>", userData.length);
            if (userData && userData.length > 0) {
                if (userData[0].status != "1") {
                    return res.status(404).send({
                        success: false,
                        status: 404,
                        message: ErrorMessage.NOT_FOUND
                    })
                } else {
                    let check = bcrypt.compare(password,userData[0].password);
                    console.log(userData[0].password)
                    console.log(check)
                    console.log("password match====>", check);
                    if (check) {
                        let token = jwt.sign({
                            id: userData[0].id,
                            expire: new Date().setMonth(new Date().getMonth() + 2)
                        }, global.gConfig.JWT_secureToken)
                        return res.status(200).send({
                            success: true,
                            status: 200,
                            message: SuccessMessage.LOGIN_SUCCESS,
                            resp: token,
                            data: userData
                        })
                    } else {
                        return res.status(404).send({
                            success: false,
                            status: 404,
                            message: ErrorMessage.PASSWORD_WRONG
                        })
                    }
                }
            }
            else {
                return res.status(404).send({
                    success: false,
                    status: 404,
                    message: ErrorMessage.INVALID_CREDENTIAL
                })
            }
        }
        catch (error) {
            return res.status(501).send({
                success: false,
                status: 501,
                error: error,
                message: ErrorMessage.SOMETHING_WRONG
            })
        }
    },
    viewUserDetail: async (req, res) => {
        try {
            let userId = req.userDetails[0].id;
            console.log("user toke ", req.userDetails[0].id);
            let query = `select * from tb_users WHERE status=1 AND id='${userId}'`; 
            let Search_userList = await mysqlDbService.readQuery(query);
            return res.status(200).send({
                success: (Search_userList.length > 0) ? true : false,
                status: 200,
                message: SuccessMessage.DATA_FOUND,
                resp: Search_userList,
            })
        } catch (error) {
            console.log("error in user detail API===>\n", error);
            return res.status(501).send({
                success: false,
                status: 501,
                error: error,
                message: ErrorMessage.SOMETHING_WRONG
            })
        }
    },
    signupUser: async (req, res) => {
        try {
            let {firstName,lastName,email,mobileNumber,country,other,password,state,ipAddress} = req.body;
            if (!firstName) {
                return res.status(400).send({
                    status: 400,
                    success: false,
                    message: "firstName not available."
                });
            };
            if (!email) {
                return res.status(400).send({
                    status: 400,
                    success: false,
                    message: "email not available."
                });
            };
            if (!mobileNumber) {
                return res.status(400).send({
                    status: 400,
                    success: false,
                    message: "mobileNumber not available."
                });
            };
            if (!country) {
                return res.status(400).send({
                    status: 400,
                    success: false,
                    message: "country not available."
                });
            };
            if (!password) {
                return res.status(400).send({
                    status: 400,
                    success: false,
                    message: "password not available."
                });
            };
            if(other==undefined){
                other = '';
            }
            if(country==1){
                country = 'US';
                if (!state) {
                    return res.status(400).send({
                        status: 400,
                        success: false,
                        message: "state not available."
                    });
                };
            } else {
                country = 'International';
                state = '';
            }
            const salt = bcrypt.genSaltSync();
            let hash = bcrypt.hashSync(password,salt);
            console.log("email ====>", email);
            let userData = await mysqlDbService.readQueryByEmail(email,'tb_users');
            console.log("userData====>", userData.length);
            if (userData && userData.length > 0) {
                return res.status(404).send({
                    success: false,
                    status: 404,
                    message: ErrorMessage.EMAIL_ALREADY_AVAILABLE
                })
            } else {
                let query = "INSERT INTO `tb_users`(`name`, `lname`, `email`, `phone`, `password`, `country`, `status`, `other`, `state`, `ipAddress`) VALUES ('"+firstName+"','"+lastName+"','"+email+"','"+mobileNumber+"','"+hash+"','"+country+"','1','"+other+"','"+state+"','"+ipAddress+"')";
                respdata = await mysqlDbService.insertRecord(query, "tb_users");
                if(respdata.affectedRows == 1) {
                    //console.log("respdata-- " + respdata.affectedRows);
                    let mailoption = {
                        from: global.gConfig.fromEmail,
                        to: email,
                        subject: "New account creation",
                        html: "Your account has been created successfully, Your login credentials user - "+email+", password - "+password+"."
                    }
                    transporter.sendMail(mailoption, function(err, response){
                        if(err) {
                            console.log(err);
                        } 
                        console.log('Message Sent' + response.message);
                        transporter.close(); 
                    });
                    return res.status(200).send({
                        success: true,
                        status: 200,
                        message: SuccessMessage.ACCOUNT_CREATION
                    })
                }
            }
        }
        catch (error) {
            return res.status(501).send({
                success: false,
                status: 501,
                error: error,
                message: ErrorMessage.SOMETHING_WRONG
            })
        }
    },
    updateUserDetail: async (req, res) => {
        try {
            let { firstName,lastName,email,mobileNumber,country,other,state } = req.body;
            if (!firstName) {
                return res.status(400).send({
                    status: 400,
                    success: false,
                    message: "firstName not available."
                });
            };
            if (!email) {
                return res.status(400).send({
                    status: 400,
                    success: false,
                    message: "email not available."
                });
            };
            if (!mobileNumber) {
                return res.status(400).send({
                    status: 400,
                    success: false,
                    message: "mobileNumber not available."
                });
            };
            if (!country) {
                return res.status(400).send({
                    status: 400,
                    success: false,
                    message: "country not available."
                });
            };
            if(other==undefined){
                other = '';
            }
            let userId = req.userDetails[0].id;
            let userData = await mysqlDbService.readQueryById(userId, 'tb_users');
            console.log("userData====>", userData.length);
            if (userData && userData.length > 0) {
                let query = `UPDATE tb_users SET 
                name='${firstName}',
                lname='${lastName}',
                phone='${mobileNumber}',
                country='${country}',
                other='${other}',
                state='${state}' WHERE 
                id='${userId}'`; 
                respdata = await mysqlDbService.insertRecord(query, "tb_users");
                if(respdata.affectedRows == 1) {
                    return res.status(200).send({
                        success: true,
                        status: 200,
                        message: SuccessMessage.PROFILE_DETAILS
                    })
                }
            } else {
                return res.status(404).send({
                    success: false,
                    status: 404,
                    message: ErrorMessage.BAD_REQUEST
                })
            }
        }
        catch (error) {
            return res.status(501).send({
                success: false,
                status: 501,
                error: error,
                message: ErrorMessage.SOMETHING_WRONG
            })
        }
    },
    resetPassword: async (req, res) => {
        try {
            let { email, password, oldPassword } = req.body;
            if (!email) {
                return res.status(400).send({
                    status: 400,
                    success: false,
                    message: "email not available."
                });
            };
            if (!password) {
                return res.status(400).send({
                    status: 400,
                    success: false,
                    message: "password not available."
                });
            };
            if (!oldPassword) {
                return res.status(400).send({
                    status: 400,
                    success: false,
                    message: "old password not available."
                });
            };
            let userData = await mysqlDbService.readQueryByEmail(email,'tb_users');
            console.log("userData====>", userData.length);
            if (userData && userData.length > 0) {
                if (userData[0].status != "1") {
                    return res.status(404).send({
                        success: false,
                        status: 404,
                        message: ErrorMessage.NOT_FOUND
                    })
                } else {
                    let check = bcrypt.compareSync(oldPassword, userData[0].password);
                    if (check) {
                        const salt = bcrypt.genSaltSync();
                        const hash = bcrypt.hashSync(password, salt);
                        let query = "UPDATE `tb_users` SET `password`='"+ hash +"' WHERE email='"+ email +"'"; 
                        let check = await mysqlDbService.updateTable(query);
                        return res.status(200).send({
                            success: true,
                            status: 200,
                            message: SuccessMessage.RESET_SUCCESS
                        }) 
                    } else {
                        return res.status(404).send({
                            success: false,
                            status: 404,
                            message: 'Old password not match!'
                        })
                    }
                }
            } else {
                return res.status(404).send({
                    success: false,
                    status: 404,
                    message: ErrorMessage.NOT_FOUND
                })
            }
        }
        catch (error) {
            return res.status(501).send({
                success: false,
                status: 501,
                error: error,
                message: ErrorMessage.SOMETHING_WRONG
            })
        }
    },
    resetPasswordAfterForgot: async (req, res) => {
        try {
            let { email, password,code } = req.body;
            if (!email) {
                return res.status(400).send({
                    status: 400,
                    success: false,
                    message: "email not available."
                });
            };
            if (!password) {
                return res.status(400).send({
                    status: 400,
                    success: false,
                    message: "password not available."
                });
            };
            if (!code) {
                return res.status(400).send({
                    status: 400,
                    success: false,
                    message: "code not available."
                });
            };
            //console.log("email ====>", email);
            let userData = await mysqlDbService.readQueryByEmailCode(email, code, 'tb_users');
            //console.log("userData====>", userData.length);
            if (userData && userData.length > 0) {
                if (userData[0].status != "1") {
                    return res.status(404).send({
                        success: false,
                        status: 404,
                        message: ErrorMessage.NOT_FOUND
                    })
                } else {
                    const salt = bcrypt.genSaltSync();
                    const hash = bcrypt.hashSync(password, salt);
                    //console.log("has ====>", hash);
                    let query = "UPDATE `tb_users` SET `password`='"+ hash +"',`code`='' WHERE email='"+ email +"'"; 
                    await mysqlDbService.updateTable(query);
                    //console.log("check.. ====>", check.changedRows);
                    return res.status(200).send({
                        success: true,
                        status: 200,
                        message: SuccessMessage.RESET_SUCCESS
                    })
                }
            } else {
                return res.status(404).send({
                    success: false,
                    status: 404,
                    message: ErrorMessage.NOT_FOUND
                })
            }
        }
        catch (error) {
            return res.status(501).send({
                success: false,
                status: 501,
                error: error,
                message: ErrorMessage.SOMETHING_WRONG
            })
        }
    },
    forgetPassword: async (req, res) => {
        try {
            let { email } = req.body;
            if (!email) {
                return res.status(400).send({
                    status: 400,
                    success: false,
                    message: "email not available."
                });
            };
            let userData = await mysqlDbService.readQueryByEmail(email, 'tb_users');
            console.log("userData====>", userData.length);
            if (userData && userData.length > 0) {
                if (userData[0].status != "1") {
                    return res.status(404).send({
                        success: false,
                        status: 404,
                        message: ErrorMessage.NOT_FOUND
                    })
                } else {
                    var code = Math.floor(100000 + Math.random() * 900000);
                    let query = "UPDATE `tb_users` SET `code`='"+ code +"' WHERE email='"+ email +"'"; 
                    await mysqlDbService.updateTable(query);
                    let mailoption = {
                        from: global.gConfig.fromEmail,
                        to: email,
                        subject: "FORGET PASSWORD",
                        html: 'You have received a new code for Forgot Password:-'+code+' and Reset Password Link - <a href="https://playg.namocart.in/reset-password-for-forgot.php">Reset Password</a>'
                    }
                    transporter.sendMail(mailoption, function(err, response){
                        if(err) {
                            console.log(err);
                        } 
                        console.log('Message Sent' + response.message);
                        transporter.close(); 
                    });
                    return res.status(200).send({
                        success: true,
                        status: 200,
                        message: SuccessMessage.FORGET_SUCCESS
                    })
                }
            } else {
                return res.status(404).send({
                    success: false,
                    status: 404,
                    message: ErrorMessage.NOT_FOUND
                })
            }
        }
        catch (error) {
            return res.status(501).send({
                success: false,
                status: 501,
                error: error,
                message: ErrorMessage.SOMETHING_WRONG
            })
        }
    }
}