const mysqlDbService = require('../../services/mysqlDbService');
const { ErrorMessage, SuccessMessage } = require('../../helpers/message');
const { async } = require('q');
const mailer = require('nodemailer');
const transporter = mailer.createTransport({
    host: global.gConfig.mailHost,
    port: global.gConfig.mailPort,
    secure: false,
    auth: {
        user: global.gConfig.authEmail,
        pass: global.gConfig.authPass
    },
    tls: {
        rejectUnauthorized: false
    }
}); 
module.exports = {
    /**
    * Function Name :contact API
    * Description :contact API
    * @return  promise response
    */
    insertContact: async (req, res) => {
        try {
            let { name,email,phone,message } = req.body;
            let subject = 'Quick Enquiry Confirmation';
            if (!name) {
                return res.status(400).send({
                    status: 400,
                    success: false,
                    message: "name not available."
                });
            };
            if (!email) {
                return res.status(400).send({
                    status: 400,
                    success: false,
                    message: "email not available."
                });
            };
            if (!phone) {
                return res.status(400).send({
                    status: 400,
                    success: false,
                    message: "phone not available."
                });
            };
            let query = `INSERT INTO tb_contact (name,email,phone,message) VALUES ('${name}','${email}','${phone}','${message}')`;
            respdata = await mysqlDbService.insertRecord(query, "tb_contact");
            if(respdata.affectedRows == 1) {
                let mailoption = {
                    from: global.gConfig.fromEmail,
                    to: email,
                    subject: subject,
                    html: "Your Query Submitted Successfully, We will reply asap.<br><br>Thanks,<br>Playmaker Team"
                }
                transporter.sendMail(mailoption, function(err, response){
                    if(err) {
                        console.log(err);
                    } 
                    //console.log('Message Sent' + response.message);
                    transporter.close(); 
                });
                return res.status(200).send({
                    success: true,
                    status: 200,
                    message: SuccessMessage.INSERT_SUCCESS
                })
            }
        }
        catch (error) {
            return res.status(501).send({
                success: false,
                status: 501,
                error: error,
                message: ErrorMessage.SOMETHING_WRONG
            })
        }
    }
}