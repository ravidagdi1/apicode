const { ErrorMessage, SuccessMessage } = require('../../helpers/message');
const mysqlDbService = require('../../services/mysqlDbService');
const { async } = require('q');
module.exports = {
    contestLists: async (req, res) => {
        try {
            let datetime = new Date();
            let date = datetime.toISOString().slice(0,10)
		    //let time = date("H:i:s");
            let query = `select * from tb_contests where endDate >='${date}' and status=1 and isComplete=0 order by id desc`; 
            //console.log(query);
            let Search_productLists = await mysqlDbService.readQuery(query);
            return res.status(200).send({
                success: (Search_productLists.length > 0) ? true : false,
                status: 200,
                message: SuccessMessage.DATA_FOUND,
                resp: Search_productLists,
            })
        } catch (error) {
            console.log("error in contest lists API===>\n", error);
            return res.status(501).send({
                success: false,
                status: 501,
                error: error,
                message: ErrorMessage.SOMETHING_WRONG
            })
        }
    },
    contestDetail: async (req, res) => {
        try {
            let { id,userId } = req.body;
            if (!id) {
                return res.status(400).send({
                    status: 400,
                    success: false,
                    message: "contest id not available."
                });
            };
            let query = `select * from tb_contests where id='${id}' and status=1`; 
            console.log(query);
            let Search_productLists = await mysqlDbService.readQuery(query);
            if(Search_productLists.length > 0) {
                for(i=0;i<Search_productLists.length;i++) {
                    let queryEx = `select * from tb_questions where contest_id=='${Search_productLists[i].id}' order by question asc`; 
                    let Search_viewExDetail = await mysqlDbService.readQuery(queryEx);
                    if(Search_viewExDetail.length > 0 && userId !='' && userId !=undefined) {
                        for(j=0;j<Search_viewExDetail.length;j++) {
                            let queryUA= `select * from tb_useranswers where userId='${userId}' and contest_id='${Search_productLists[i].id}' and question='${Search_viewExDetail[j].question}'`; 
                            let search_re = await mysqlDbService.readQuery(queryUA);
                            if(search_re.length > 0) {
                                Search_viewExDetail[j]["userAnswer"] = search_re[0].userAnswer;
                            }
                        }
                    }
                    Search_productLists[i]["items"] = Search_viewExDetail;
                }
            }
            let queryP = `select * from tb_contest_price where contest_id='${id}' order by rank asc`; 
            //console.log(queryP);
            let search_price = await mysqlDbService.readQuery(queryP);
            return res.status(200).send({
                success: (Search_productLists.length > 0) ? true : false,
                status: 200,
                message: SuccessMessage.DATA_FOUND,
                resp: Search_productLists,
                pricelist: search_price,
            })
        } catch (error) {
            console.log("error in contest detail API===>\n", error);
            return res.status(501).send({
                success: false,
                status: 501,
                error: error,
                message: ErrorMessage.SOMETHING_WRONG
            })
        }
    },
    uploadContest: async (req, res) => {
        try {
            let { contest_id,items } = req.body;
            if (!contest_id) {
                return res.status(400).send({
                    status: 400,
                    success: false,
                    message: "contest id not available."
                });
            };
            let userId = req.userDetails[0].id;  
            let datetime = new Date();
            let answerDate = datetime.toISOString().slice(0,10); 
            let answerTime = datetime.toISOString().slice(11,19);          
            for(i=0;i<items.length;i++) {
                let query = `INSERT INTO tb_useranswers(userId,contest_id,question_id,question,userAnswer,type,rightAnswer,isRight,answerDate,answerTime) VALUES ('${userId}','${contest_id}','${items[i].question_id}','${items[i].question}','${items[i].userAnswer}','${items[i].type}','','0','${answerDate}','${answerTime}')`;
                await mysqlDbService.insertRecord(query, "tb_useranswers");
            }
            return res.status(200).send({
                success: true,
                status: 200,
                message: SuccessMessage.INSERT_SUCCESS
            })
        } catch (error) {
            console.log("error in add question API===>\n", error);
            return res.status(501).send({
                success: false,
                status: 501,
                error: error,
                message: ErrorMessage.SOMETHING_WRONG
            })
        }
    },
    contestReport: async (req, res) => {
        try {
            let { id } = req.body;
            if (!id) {
                return res.status(400).send({
                    status: 400,
                    success: false,
                    message: "contest id not available."
                });
            };
            let query = `select * from tb_contests where id='${id}' and status=1`; 
            //console.log(query);
            let Search_productLists = await mysqlDbService.readQuery(query);
            if(Search_productLists.length > 0) {
                for(i=0;i<Search_productLists.length;i++) {
                    let queryEx = `SELECT uId,name,SUM(points) as points,rank,answerTime FROM tb_leaderboard where contest_id='${id}' GROUP BY uId ORDER BY points desc,answerTime asc`; 
                    let Search_viewExDetail = await mysqlDbService.readQuery(queryEx);
                    Search_productLists[i]["items"] = Search_viewExDetail;
                }
            }
            return res.status(200).send({
                success: (Search_productLists.length > 0) ? true : false,
                status: 200,
                message: SuccessMessage.DATA_FOUND,
                resp: Search_productLists,
            })
        } catch (error) {
            console.log("error in contest report API===>\n", error);
            return res.status(501).send({
                success: false,
                status: 501,
                error: error,
                message: ErrorMessage.SOMETHING_WRONG
            })
        }
    },
    userReport: async (req, res) => {
        try {
            let userId = req.userDetails[0].id;  
            let query = `select l.*,c.name as cname from tb_leaderboard as l,tb_contests as c where l.contest_id=c.id and l.uId='${userId}' order by l.id desc`; 
            let Search_productLists = await mysqlDbService.readQuery(query);
            if(Search_productLists.length > 0) {
                for(i=0;i<Search_productLists.length;i++) {
                    let queryEx = `select count(id) as tot from tb_leaderboard where contest_id='${Search_productLists[i].contest_id}'`; 
                    let totR = await mysqlDbService.readQuery(queryEx);
                    if(totR.length > 0) {
                        Search_productLists[i]["outofrank"] = totR[0].tot;
                    }
                    let queryP = `select * from tb_contest_price where rank='${Search_productLists[i].rank}' and contest_id='${Search_productLists[i].contest_id}'`; 
                    let rePrice = await mysqlDbService.readQuery(queryP);
                    if(rePrice.length > 0) {
                        Search_productLists[i]["prize"] = rePrice[0].price;
                        let queryCP = `select * from tb_claimprize where uId='${userId}' and contest_id='${Search_productLists[i].contest_id}'`; 
                        let fetchCP = await mysqlDbService.readQuery(queryCP);
                        if(fetchCP.length > 0) {
                            Search_productLists[i]["isClaim"] = 1;
                        } else {
                            Search_productLists[i]["isClaim"] = 0;
                        }
                    }
                }
            }
            return res.status(200).send({
                success: (Search_productLists.length > 0) ? true : false,
                status: 200,
                message: SuccessMessage.DATA_FOUND,
                resp: Search_productLists,
            })
        } catch (error) {
            console.log("error in user report API===>\n", error);
            return res.status(501).send({
                success: false,
                status: 501,
                error: error,
                message: ErrorMessage.SOMETHING_WRONG
            })
        }
    },
    claimPrize: async (req, res) => {
        try {
            let {contest_id,price,rank} = req.body;
            if (!contest_id) {
                return res.status(400).send({
                    status: 400,
                    success: false,
                    message: "contest_id not available."
                });
            };
            if (!price) {
                return res.status(400).send({
                    status: 400,
                    success: false,
                    message: "prize not available."
                });
            };
            if (!rank) {
                return res.status(400).send({
                    status: 400,
                    success: false,
                    message: "rank not available."
                });
            };
            let userId = req.userDetails[0].id; 
            let query = `INSERT INTO tb_claimprize SET uId='${userId}',contest_id='${contest_id}',price='${price}',rank='${rank}'`;
            respdata = await mysqlDbService.insertRecord(query, "tb_claimprize");
            if(respdata.affectedRows == 1) {
                return res.status(200).send({
                    success: true,
                    status: 200,
                    message: SuccessMessage.INSERT_SUCCESS
                })
            }
        } catch (error) {
            return res.status(501).send({
                success: false,
                status: 501,
                error: error,
                message: ErrorMessage.SOMETHING_WRONG
            })
        }
    }
}